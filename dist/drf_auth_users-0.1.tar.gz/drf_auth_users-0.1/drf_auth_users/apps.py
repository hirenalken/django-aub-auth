from django.apps import AppConfig


class AuthenticationConfig(AppConfig):
    name = 'drf_auth_users'
